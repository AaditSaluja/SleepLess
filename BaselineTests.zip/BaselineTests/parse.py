def parse_benchmark_file(file_path):
    """
    Parse a benchmark file and extract CPU_load values for different augmentations.
    Calculates both:
    1. Average CPU_load excluding the first epoch
    2. Ratio of first epoch's CPU_load to the average of remaining epochs
    """
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Dictionary to store CPU_load values for each augmentation
    augmentation_data = {}
    current_aug = None
    
    # Process each line
    for line in content.split('\n'):
        # Check if line indicates a new augmentation section
        if line.startswith('=== AUG='):
            # Extract augmentation name
            aug_name = line.split('|')[0].strip().replace('=== AUG=', '').strip()
            current_aug = aug_name
            augmentation_data[current_aug] = []
        
        # Check if line contains epoch data
        elif line.startswith('Epoch') and current_aug is not None:
            # Extract CPU_load value
            parts = line.split(',')
            if len(parts) > 0:
                cpu_load_part = parts[0]
                cpu_load_str = cpu_load_part.split('=')[1].strip()
                cpu_load = float(cpu_load_str.replace(' ms', ''))
                augmentation_data[current_aug].append(cpu_load)
    
    # Calculate averages and ratios
    results = {}
    for aug, values in augmentation_data.items():
        if len(values) > 1:
            first_epoch = values[0]
            remaining_epochs = values[1:]
            avg_remaining = sum(remaining_epochs) / len(remaining_epochs)
            ratio = first_epoch / avg_remaining if avg_remaining != 0 else 0
            
            results[aug] = {
                'first_epoch': first_epoch,
                'avg_remaining': avg_remaining,
                'ratio': ratio
            }
    
    return results

def main():
    file_path = "run_B128_WRK31.out"  # Change this to your actual file path
    
    try:
        results = parse_benchmark_file(file_path)
        
        print("CPU_load Analysis for Different Augmentations:")
        print("-" * 75)
        print(f"{'Augmentation':<10} | {'First Epoch (ms)':<15} | {'Avg Others (ms)':<15} | {'Ratio (First/Avg)':<15}")
        print("-" * 75)
        
        for aug, data in results.items():
            print(f"{aug:<10} | {data['first_epoch']:<15.2f} | {data['avg_remaining']:<15.2f} | {data['ratio']:<15.2f}")
            
    except Exception as e:
        print(f"Error processing the file: {e}")

if __name__ == "__main__":
    main()