import os
import time
import torch
import torchvision.transforms as transforms
from torch import nn, optim
from torch.cuda import Event
from torchvision.datasets import CIFAR10, ImageFolder
from torch.utils.data import DataLoader
# from torchvision.models import resnet50
import random
import numpy as np
from torchvision.models import resnet50, ResNet50_Weights


# 1) Fix seeds
seed = 0
os.environ['PYTHONHASHSEED'] = str(seed)
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed_all(seed)

# 2) Make cuDNN deterministic
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

def get_dataloader(dataset: str,
                   data_dir: str,
                   image_size: int,
                   batch_size: int,
                   num_workers: int = 4):
    transform = transforms.Compose([
        transforms.Resize(image_size),
        transforms.CenterCrop(image_size),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std= [0.229, 0.224, 0.225]),
    ])

    if dataset.lower() == 'cifar10':
        ds = CIFAR10(root=data_dir, train=True, download=True, transform=transform)
        num_classes = 10
    elif dataset.lower() == 'imagenet1k':
        ds = ImageFolder(root=data_dir, transform=transform)
        # assumes your folder has 1000 subfolders, one per class
        num_classes = 1000
    else:
        raise ValueError(f"Unknown dataset {dataset}")

    loader = DataLoader(
        ds,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True
    )
    return loader, num_classes

def run_experiment(dataset: str,
                   data_dir: str,
                   image_size: int,
                   batch_size: int,
                   epochs: int = 5):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    loader, num_classes = get_dataloader(dataset, data_dir, image_size, batch_size)

    model = resnet50(weights=None, num_classes=num_classes).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=0.01, momentum=0.9)

    print(f"\n>>> {dataset.upper():12s} | {image_size:3d}×{image_size:3d} | "
          f"bs={batch_size:3d} | classes={num_classes}")
    for epoch in range(1, epochs+1):
        cpu_prep_times, gpu_times, cpu_idle_times = [], [], []
        model.train()

        # warm-up
        for _ in range(3):
            dummy_inp = torch.randn(batch_size, 3, image_size, image_size, device=device)
            _ = model(dummy_inp)

        # timed batches
        for inputs, labels in loader:
            # 1) prep
            t_prep_start = time.perf_counter()
            inputs = inputs.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            torch.cuda.synchronize()
            t_prep_end = time.perf_counter()

            # 2) GPU
            evt_start = Event(enable_timing=True)
            evt_end   = Event(enable_timing=True)
            evt_start.record()

            # 3) forward/backward/step
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # 4) sync + end
            evt_end.record()
            torch.cuda.synchronize()
            t_total_end = time.perf_counter()

            # 5) compute segments
            prep_ms  = (t_prep_end  - t_prep_start) * 1e3
            gpu_ms   = evt_start.elapsed_time(evt_end)
            total_ms = (t_total_end - t_prep_start) * 1e3
            idle_ms  = total_ms - prep_ms - gpu_ms

            cpu_prep_times.append(prep_ms)
            gpu_times.append(gpu_ms)
            cpu_idle_times.append(idle_ms)

        # fixed formatting here
        print(
            f"Epoch {epoch:2d} → "
            f"CPU prep avg {sum(cpu_prep_times)/len(cpu_prep_times):6.2f} ms | "
            f"GPU avg     {sum(gpu_times)/len(gpu_times):6.2f} ms | "
            f"CPU idle avg {sum(cpu_idle_times)/len(cpu_idle_times):6.2f} ms"
        )



if __name__ == "__main__":
    print("ResNet50 training on CIFAR-10 and ImageNet-1k")

    experiments = [
        # CIFAR-10 @  32×32
        {
          'dataset':    'cifar10',
          'data_dir':   '/n/idreos_lab/users/1/aadit_tori/',       # will download to ./data
          'image_size': 32,
          'batch_size': 128,
        },
        # ImageNet-1k @ 224×224
        {
          'dataset':    'imagenet1k',
          'data_dir':   '/n/idreos_lab/users/usirin/datasets/imagenet_subsets/imagenet_training_1000class/'
                         'train',
          'image_size': 224,
          'batch_size':  64,
        },
        # ImageNet-1k @ 512×512
        {
          'dataset':    'imagenet1k',
          'data_dir':   '/n/idreos_lab/users/usirin/datasets/imagenet_subsets/imagenet_training_1000class/'
                         'train',
          'image_size': 512,
          'batch_size':  32,
        },
    ]

    for exp in experiments:
        run_experiment(**exp)
