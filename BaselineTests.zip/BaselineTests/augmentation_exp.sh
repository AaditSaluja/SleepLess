#!/bin/bash
#SBATCH -c 32                                 # CPU cores
#SBATCH --gres=gpu:1                           # one GPU
#SBATCH --exclusive                            # no other jobs on the node
#SBATCH -t 0-12:00                             # D-HH:MM
#SBATCH -p seas_gpu                            # Partition to submit to
#SBATCH --mem=64000
#SBATCH -o full_run_%j.out
#SBATCH -e full_run_%j.err
#SBATCH --constraint=a100|h100

image_size=224
batch_size=128
num_workers=8
epochs=5
batches_per_epoch=9001

# ──────────────────────────────────────────────────────────────────────────────
# 0) PRINT HARDWARE INFO
# ──────────────────────────────────────────────────────────────────────────────
echo "===== CPU INFO ====="
lscpu
echo
echo "===== GPU INFO ====="
nvidia-smi --query-gpu=index,name,driver_version,memory.total --format=csv
echo

# ──────────────────────────────────────────────────────────────────────────────
# 1) START BACKGROUND UTIL MONITORS
# ──────────────────────────────────────────────────────────────────────────────
# sample CPU usage every second
mpstat -P ALL 1 > cpu_util.log 2>&1 &
MPSTAT_PID=$!
# sample GPU utilization every second
nvidia-smi --query-gpu=timestamp,utilization.gpu,utilization.memory \
          --format=csv -l 1 > gpu_util.log 2>&1 &
GPU_MON_PID=$!

# ──────────────────────────────────────────────────────────────────────────────
# 2) ENV SETUP
# ──────────────────────────────────────────────────────────────────────────────
module load python/3.10.9-fasrc01 cuda/12.0.1-fasrc01 cudnn
mamba activate whatover

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
export MKL_NUM_THREADS=1
export PYTHONHASHSEED=0



# ──────────────────────────────────────────────────────────────────────────────
# 3) RUN EXPERIMENT
# ──────────────────────────────────────────────────────────────────────────────
python VaryingAugmentation.py $image_size $batch_size $num_workers $epochs $batches_per_epoch 
# ──────────────────────────────────────────────────────────────────────────────
# 4) STOP MONITORS
# ──────────────────────────────────────────────────────────────────────────────
kill $MPSTAT_PID $GPU_MON_PID || true
echo "Background monitors stopped. Logs: cpu_util.log, gpu_util.log"
