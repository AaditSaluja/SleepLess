#!/usr/bin/env python3
import os
import random
import time
import numpy as np
import torch
import psutil                  # pip install psutil
import pynvml
import argparse
from torch import nn, optim
from torch.cuda import Event
from torchvision import transforms
from torchvision.datasets import ImageFolder
from torch.utils.data import DataLoader
from torchvision.models import resnet50

# ──────────────────────────────────────────────────────────────────────────────
# 1) FIX SEEDS & MAKE CUDNN DETERMINISTIC
# ──────────────────────────────────────────────────────────────────────────────
seed = 0
os.environ['PYTHONHASHSEED'] = str(seed)
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed_all(seed)
torch.backends.cudnn.benchmark     = False
torch.backends.cudnn.deterministic = True

def print_hardware_info():
    print("=== Python-reported Hardware Info ===")
    # CPU
    cpu = psutil.cpu_freq()
    print(f"CPU cores: {psutil.cpu_count(logical=False)} physical, "
          f"{psutil.cpu_count(logical=True)} logical")
    print(f"Max frequency: {cpu.max:.0f} MHz, Min: {cpu.min:.0f} MHz")
    # GPU
    pynvml.nvmlInit()
    handle = pynvml.nvmlDeviceGetHandleByIndex(0)
    name = pynvml.nvmlDeviceGetName(handle)
    # only decode if it's bytes
    if isinstance(name, bytes):
        name = name.decode("utf-8", errors="ignore")
    mem = pynvml.nvmlDeviceGetMemoryInfo(handle).total // (1024**2)
    print(f"GPU      : {name}, {mem} MiB")
    print("="*50, "\n")

# ──────────────────────────────────────────────────────────────────────────────
# 2) AUGMENTATION PRESETS
# ──────────────────────────────────────────────────────────────────────────────
def get_imagenet_transform(level: str, image_size: int):
    """Returns a torchvision transform for the given augmentation level."""
    norm = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                std= [0.229, 0.224, 0.225])
    if level == 'zero':
        return transforms.Compose([
            transforms.RandomResizedCrop(image_size),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485,0.456,0.406],
                                std= [0.229,0.224,0.225]),
        ])
    elif level == 'none':
        return transforms.Compose([
            transforms.Resize(image_size),
            transforms.CenterCrop(image_size),
            transforms.ToTensor(),
            norm,
        ])
    elif level == 'light':
        return transforms.Compose([
            transforms.RandomResizedCrop(image_size, scale=(0.8, 1.0)),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.ToTensor(),
            norm,
        ])
    elif level == 'medium':
        return transforms.Compose([
            transforms.RandomResizedCrop(image_size),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1),
            transforms.ToTensor(),
            norm,
        ])
    elif level == 'heavy':
        # Move RandomErasing after ToTensor and Normalize to operate on tensors
        return transforms.Compose([
            transforms.RandomResizedCrop(image_size),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.2),
            transforms.RandomRotation(degrees=15),
            transforms.ToTensor(),
            norm,
            transforms.RandomErasing(scale=(0.02, 0.33), ratio=(0.3, 3.3), p=0.25),
        ])
    else:
        raise ValueError(f"Unknown augmentation level: {level}")

# ──────────────────────────────────────────────────────────────────────────────
# 3) DATALOADER FACTORY
# ──────────────────────────────────────────────────────────────────────────────
def get_imagenet_loader(data_dir: str,
                        image_size: int,
                        batch_size: int,
                        num_workers: int,
                        aug_level: str):
    transform = get_imagenet_transform(aug_level, image_size)
    ds = ImageFolder(root=data_dir, transform=transform)
    loader = DataLoader(ds,
                        batch_size=batch_size,
                        shuffle=True,
                        num_workers=num_workers,
                        pin_memory=True)
    return loader, len(ds.classes)

# ──────────────────────────────────────────────────────────────────────────────
# 4) SINGLE-RUN EXPERIMENT
# ──────────────────────────────────────────────────────────────────────────────
def run_once(data_dir: str,
             image_size: int,
             batch_size: int,
             num_workers: int,
             aug_level: str,
             epochs: int = 3,
             batches_per_epoch: int = 50):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    loader, num_classes = get_imagenet_loader(data_dir, image_size,
                                              batch_size, num_workers,
                                              aug_level)

    model     = resnet50(weights=None, num_classes=num_classes).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=0.01, momentum=0.9)

    print(f"\n=== AUG={aug_level.upper():6s} | SZ={image_size} | BS={batch_size} "
          f"| WRK={num_workers} | CL={num_classes} ===")

    for epoch in range(1, epochs + 1):
        cpu_load, gpu_times, cpu_idle, gpu_idle = [], [], [], []
        model.train()

        # warm-up
        for _ in range(3):
            dummy = torch.randn(batch_size, 3, image_size, image_size, device=device)
            _ = model(dummy)

        data_iter = iter(loader)

        # print number of possible batches
        print(f"Number of batches per epoch: {len(loader)}")
        for _ in range(batches_per_epoch):
            # 1) CPU load + augmentation
            t0 = time.perf_counter()
            inputs, labels = next(data_iter)
            t1 = time.perf_counter()

            # async transfer to device
            inputs = inputs.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            torch.cuda.synchronize()

            # 2) GPU timing start
            start_evt = Event(enable_timing=True)
            end_evt   = Event(enable_timing=True)
            start_evt.record()

            # 3) forward/backward + step
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # 4) GPU timing end
            end_evt.record()
            torch.cuda.synchronize()
            t2 = time.perf_counter()

            load_ms  = (t1 - t0) * 1e3
            gpu_ms   = start_evt.elapsed_time(end_evt)
            total_ms = (t2 - t0) * 1e3
            idle_ms  = total_ms - load_ms - gpu_ms
            gpu_idle_ms = total_ms - gpu_ms

            cpu_load.append(load_ms)
            gpu_times.append(gpu_ms)
            cpu_idle.append(idle_ms)
            gpu_idle.append(gpu_idle_ms)

            

        # summary for epoch
        print(f"Epoch {epoch:02d} → "
              f"CPU_load={np.mean(cpu_load):6.2f} ms, "
              f"GPU={np.mean(gpu_times):6.2f} ms, "
              f"CPU_idle={np.mean(cpu_idle):6.2f} ms, "
              f"GPU_idle={np.mean(gpu_idle):6.2f} ms,", flush=True)

# ──────────────────────────────────────────────────────────────────────────────
# 5) MAIN: VARY AUGMENTATION LEVELS & USER SETTINGS
# ──────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":

    parser = argparse.ArgumentParser(
        description="Run augmentation‐level experiments on ResNet50"
    )

    DATA_DIR    = '/n/idreos_lab/users/usirin/datasets/imagenet_subsets/imagenet_training_1000class/train'
    parser.add_argument("image_size", type=int, help="Image size", default=224)
    parser.add_argument("batch_size", type=int, help="Batch size", default=64)
    parser.add_argument("num_workers", type=int, help="Number of workers", default=31)
    parser.add_argument("epochs", type=int, help="Number of epochs", default=1)
    parser.add_argument("batches_per_epoch", type=int, help="Batches per epoch", default=100)
    args = parser.parse_args()

    IMAGE_SIZE  = args.image_size
    BATCH_SIZE  = args.batch_size
    NUM_WORKERS = args.num_workers
    EPOCHS      = args.epochs
    BPE         = args.batches_per_epoch   # batches per epoch

    print(f"Running with {NUM_WORKERS} workers, "
          f"batch size {BATCH_SIZE}, "
          f"image size {IMAGE_SIZE}, "
          f"epochs {EPOCHS}, "
          f"batches per epoch {BPE}")

    print_hardware_info()

    for aug in ['zero', 'none', 'light', 'medium', 'heavy']:
        run_once(DATA_DIR, IMAGE_SIZE, BATCH_SIZE,
                 NUM_WORKERS, aug,
                 epochs=EPOCHS, batches_per_epoch=BPE)
