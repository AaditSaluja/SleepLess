#!/bin/bash
#SBATCH -c 32                                 # CPU cores
#SBATCH --gres=gpu:1                           # one GPU
# SBATCH --exclusive                            # no other jobs on the node
#SBATCH -t 0-08:00                             # D-HH:MM
#SBATCH -p gpu_test                        # Partition to submit to
#SBATCH --mem=64000
#SBATCH -o run_resnet50_food_%j.out
#SBATCH -e run_resnet50_food_%j.err
# SBATCH --constraint=a100|h100

module load python/3.10.9-fasrc01 cuda/12.0.1-fasrc01 cudnn
mamba activate whatover

# Pin threads and seeds for reproducibility
export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
export MKL_NUM_THREADS=1
export PYTHONHASHSEED=0

python ResNet50_Food.py
