#!/usr/bin/env python3
import os
import random
import time
import numpy as np

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader

import torchvision.transforms as T
from torchvision.datasets import STL10
from torchvision.models import resnet50

from torch.cuda import Event

import torchaudio
from torchaudio.datasets import SPEECHCOMMANDS
from torchaudio.transforms import MelSpectrogram, AmplitudeToDB

# ──────────── 1) SEED & DEVICE ──────────────────────────────────────────────
seed = 0
os.environ['PYTHONHASHSEED'] = str(seed)
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)

device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
sync   = torch.cuda.synchronize if device.type == 'cuda' else (lambda: None)

# ──────────── 2) SYNTHETIC TEXT DATASET ────────────────────────────────────
class SyntheticText(Dataset):
    def __init__(self, num_samples, seq_len, vocab_size, num_classes):
        self.N, self.L, self.V, self.C = num_samples, seq_len, vocab_size, num_classes
    def __len__(self):
        return self.N
    def __getitem__(self, idx):
        txt = torch.randint(0, self.V, (self.L,), dtype=torch.long)
        lbl = torch.randint(0, self.C, (1,)).item()
        return txt, lbl

def collate_text(batch):
    texts, labels = zip(*batch)
    return torch.stack(texts), torch.tensor(labels, dtype=torch.long)

# ──────────── 3) IMAGE DATASET (STL10) ───────────────────────────────────────
img_tf = T.Compose([
    T.RandomCrop(96, padding=4),
    T.RandomHorizontalFlip(),
    T.ToTensor(),
    T.Normalize(mean=[0.440, 0.439, 0.406],
                std=[0.278, 0.280, 0.293]),
])
stl_loader = DataLoader(
    STL10(root='/n/idreos_lab/users/1/aadit_tori/', split='train', download=True, transform=img_tf),
    batch_size=64, shuffle=True, num_workers=0, drop_last=True, pin_memory=True
)

# ──────────── 4) AUDIO DATASET (SpeechCommands) ─────────────────────────────
class SC(SPEECHCOMMANDS):
    def __init__(self, root, transform):
        super().__init__(root, download=True)
        self.transform = transform
        # build label list from subdirectories
        self.labels = sorted(d for d in os.listdir(self._path)
                             if os.path.isdir(os.path.join(self._path, d)))
        self.l2i = {l:i for i,l in enumerate(self.labels)}

    def __len__(self):
        return len(self._walker)

    def __getitem__(self, idx):
        rel = self._walker[idx]  # e.g. "yes/0a7c2a8d_nohash_0.wav"
        label_name = rel.split(os.sep)[0]
        full_path = os.path.join(self._path, rel)
        waveform, sr = torchaudio.load(full_path)
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
        mel = self.transform(waveform)  # [1, n_mels, T]
        Tgt = 32
        if mel.shape[-1] < Tgt:
            pad = torch.zeros(1, mel.shape[1], Tgt - mel.shape[-1])
            mel = torch.cat([mel, pad], dim=-1)
        else:
            mel = mel[..., :Tgt]
        return mel, self.l2i[label_name]

mel_tf = nn.Sequential(
    MelSpectrogram(sample_rate=16000, n_fft=1024, hop_length=512, n_mels=64),
    AmplitudeToDB()
)
aud_ds     = SC(root='/n/idreos_lab/users/1/aadit_tori/', transform=mel_tf)
aud_loader = DataLoader(
    aud_ds, batch_size=64, shuffle=True,
    num_workers=0, drop_last=True, pin_memory=True
)

# ──────────── 5) FUSION MODEL ────────────────────────────────────────────────
class FusionModel(nn.Module):
    def __init__(self, use_img, use_txt, use_aud, vocab_size):
        super().__init__()
        self.use_img, self.use_txt, self.use_aud = use_img, use_txt, use_aud

        if use_img:
            # ResNet-50 → 128-dim features
            base = resnet50(weights=None)
            self.img_enc = nn.Sequential(base, nn.Flatten(), nn.Linear(1000, 128))

        if use_txt:
            # simple embedding + mean pool
            self.txt_emb = nn.Embedding(vocab_size, 128)

        if use_aud:
            # small CNN → 128-dim
            self.aud_enc = nn.Sequential(
                nn.Conv2d(1, 16, 3, padding=1), nn.ReLU(),
                nn.AdaptiveAvgPool2d((1,1)), nn.Flatten(),
                nn.Linear(16, 128)
            )

        fusion_dim = (128 if use_img else 0) \
                   + (128 if use_txt else 0) \
                   + (128 if use_aud else 0)
        # fixed 10-way head for profiling
        self.classifier = nn.Sequential(
            nn.Linear(fusion_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 10)
        )

    def forward(self, img=None, txt=None, aud=None):
        feats = []
        if self.use_img:
            feats.append(self.img_enc(img))
        if self.use_txt:
            x = self.txt_emb(txt)          # [B, L, D]
            feats.append(x.mean(dim=1))    # [B, D]
        if self.use_aud:
            feats.append(self.aud_enc(aud))
        return self.classifier(torch.cat(feats, dim=1))

# ──────────── 6) RUN FUNCTIONS ───────────────────────────────────────────────
def run_text_only(txt_loader):
    model = FusionModel(False, True, False, vocab_size=1000).to(device)
    opt   = optim.Adam(model.parameters(), lr=1e-3)
    lossf = nn.CrossEntropyLoss()
    for ep in range(1, 6):
        cpuL, gpuC, cpuI = [], [], []
        model.train()
        for txt, lbl in txt_loader:
            t0 = time.perf_counter()
            t1 = time.perf_counter()
            txt = txt.to(device, non_blocking=True)
            lbl = lbl.to(device, non_blocking=True)
            sync()

            evt0 = Event(enable_timing=True)
            evt1 = Event(enable_timing=True)
            evt0.record()
            out = model(txt=txt)
            loss = lossf(out, lbl)
            opt.zero_grad(); loss.backward(); opt.step()
            evt1.record()
            sync()
            t2 = time.perf_counter()

            cpuL.append((t1 - t0) * 1e3)
            gpuC.append(evt0.elapsed_time(evt1))
            cpuI.append((t2 - t0) * 1e3 - cpuL[-1] - gpuC[-1])

        print(f"[Text]      EP{ep}| load {np.mean(cpuL):5.1f}ms | "
              f"comp {np.mean(gpuC):5.1f}ms | idle {np.mean(cpuI):5.1f}ms")

def run_image_only(img_loader):
    model = FusionModel(True, False, False, vocab_size=1000).to(device)
    opt   = optim.SGD(model.parameters(), lr=0.01, momentum=0.9)
    lossf = nn.CrossEntropyLoss()
    for ep in range(1, 6):
        cpuL, gpuC, cpuI = [], [], []
        model.train()
        for imgs, lbl in img_loader:
            t0 = time.perf_counter()
            t1 = time.perf_counter()
            imgs = imgs.to(device, non_blocking=True)
            lbl  = lbl.to(device, non_blocking=True)
            sync()

            evt0 = Event(enable_timing=True)
            evt1 = Event(enable_timing=True)
            evt0.record()
            out = model(img=imgs)
            loss = lossf(out, lbl)
            opt.zero_grad(); loss.backward(); opt.step()
            evt1.record()
            sync()
            t2 = time.perf_counter()

            cpuL.append((t1 - t0) * 1e3)
            gpuC.append(evt0.elapsed_time(evt1))
            cpuI.append((t2 - t0) * 1e3 - cpuL[-1] - gpuC[-1])

        print(f"[STL10]     EP{ep}| load {np.mean(cpuL):5.1f}ms | "
              f"comp {np.mean(gpuC):5.1f}ms | idle {np.mean(cpuI):5.1f}ms")

def run_multimodal(txt_loader, img_loader, aud_loader):
    # zip stops at shortest loader
    loader = zip(txt_loader, img_loader, aud_loader)
    model = FusionModel(True, True, True, vocab_size=1000).to(device)
    opt   = optim.Adam(model.parameters(), lr=1e-3)
    lossf = nn.CrossEntropyLoss()
    for ep in range(1, 6):
        cpuL, gpuC, cpuI = [], [], []
        model.train()
        for (txt, lbl_txt), (imgs, _), (aud, _) in loader:
            t0 = time.perf_counter()
            t1 = time.perf_counter()
            txt  = txt.to(device, non_blocking=True)
            imgs = imgs.to(device, non_blocking=True)
            aud  = aud.to(device, non_blocking=True)
            lbl  = lbl_txt.to(device, non_blocking=True)
            sync()

            evt0 = Event(enable_timing=True)
            evt1 = Event(enable_timing=True)
            evt0.record()
            out = model(img=imgs, txt=txt, aud=aud)
            loss = lossf(out, lbl)
            opt.zero_grad(); loss.backward(); opt.step()
            evt1.record()
            sync()
            t2 = time.perf_counter()

            cpuL.append((t1 - t0) * 1e3)
            gpuC.append(evt0.elapsed_time(evt1))
            cpuI.append((t2 - t0) * 1e3 - cpuL[-1] - gpuC[-1])

        print(f"[Fusion]    EP{ep}| load {np.mean(cpuL):5.1f}ms | "
              f"comp {np.mean(gpuC):5.1f}ms | idle {np.mean(cpuI):5.1f}ms")

# ──────────── 7) LOADERS & RUN ───────────────────────────────────────────────
txt_loader = DataLoader(
    SyntheticText(20000, 32, 1000, 5),
    batch_size=64, shuffle=True, num_workers=0, drop_last=True,
    collate_fn=collate_text
)

img_loader = stl_loader

aud_loader = aud_loader

if __name__ == "__main__":
    run_text_only(txt_loader)
    run_image_only(img_loader)
    run_multimodal(txt_loader, img_loader, aud_loader)
