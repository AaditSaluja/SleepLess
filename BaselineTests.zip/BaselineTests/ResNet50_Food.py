#!/usr/bin/env python3
import os
import random
import time
import numpy as np
import torch
import torchvision.transforms as transforms
from torch import nn, optim
from torch.cuda import Event
from torchvision.datasets import CIFAR10, ImageFolder, Food101
from torch.utils.data import DataLoader
from torchvision.models import resnet50, ResNet50_Weights

# ──────────────────────────────────────────────────────────────────────────────
# 1) FIX SEEDS & MAKE CUDNN DETERMINISTIC
# ──────────────────────────────────────────────────────────────────────────────
seed = 0
os.environ['PYTHONHASHSEED'] = str(seed)
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed_all(seed)

torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

# ──────────────────────────────────────────────────────────────────────────────
# 2) DATALOADER FACTORY
# ──────────────────────────────────────────────────────────────────────────────
def get_dataloader(dataset: str,
                   data_dir: str,
                   image_size: int,
                   batch_size: int,
                   num_workers: int):
    """
    Returns a DataLoader and number of classes.
    For 'food101', we force num_workers=0 so augmentations happen inline.
    """
    if dataset.lower() == 'cifar10':
        transform = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.4914,0.4822,0.4465],
                                std= [0.2470,0.2435,0.2616]),
        ])
        ds = CIFAR10(root=data_dir, train=True, download=True, transform=transform)
        num_classes = 10

    elif dataset.lower() == 'imagenet1k':
        transform = transforms.Compose([
            transforms.RandomResizedCrop(image_size),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485,0.456,0.406],
                                std= [0.229,0.224,0.225]),
        ])
        ds = ImageFolder(root=data_dir, transform=transform)
        num_classes = len(ds.classes)

    elif dataset.lower() == 'food101':
        transform = transforms.Compose([
            transforms.RandomResizedCrop(image_size),
            transforms.RandomHorizontalFlip(),
            transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4),
            transforms.RandomRotation(degrees=15),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std= [0.229, 0.224, 0.225]),
        ])
        ds = Food101(root=data_dir, split='train', download=True, transform=transform)
        num_classes = 101

    else:
        raise ValueError(f"Unknown dataset {dataset}")

    loader = DataLoader(
        ds,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True
    )
    return loader, num_classes

# ──────────────────────────────────────────────────────────────────────────────
# 3) EXPERIMENT RUNNER
# ──────────────────────────────────────────────────────────────────────────────
def run_experiment(dataset: str,
                   data_dir: str,
                   image_size: int,
                   batch_size: int,
                   num_workers: int,
                   epochs: int = 5):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    loader, num_classes = get_dataloader(dataset, data_dir, image_size,
                                         batch_size, num_workers)

    model = resnet50(weights=None, num_classes=num_classes).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=0.01, momentum=0.9)

    print(f"\n>>> {dataset.upper():10s} | {image_size:3d}×{image_size:3d} | "
          f"bs={batch_size:3d} | workers={num_workers:2d} | classes={num_classes}")
    for epoch in range(1, epochs + 1):
        cpu_load_times, gpu_times, cpu_idle_times = [], [], []
        model.train()

        # ─── WARM-UP ────────────────────────────────────────────────────────────
        for _ in range(3):
            dummy = torch.randn(batch_size, 3, image_size, image_size, device=device)
            _ = model(dummy)

        data_iter = iter(loader)
        # ─── TIMED BATCHES ──────────────────────────────────────────────────────
        print(f" loader size: {len(loader)}")
        # for _ in range(len(loader)):
        for _ in range(50):
            # 1) CPU load + augmentation timer start
            t_load_start = time.perf_counter()
            inputs, labels = next(data_iter)
            t_load_end   = time.perf_counter()

            # async copy to device
            inputs = inputs.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            torch.cuda.synchronize()

            # 2) GPU timer start
            evt_start = Event(enable_timing=True)
            evt_end   = Event(enable_timing=True)
            evt_start.record()

            # 3) forward / backward / step
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # 4) GPU timer end + sync
            evt_end.record()
            torch.cuda.synchronize()
            t_total_end = time.perf_counter()

            # 5) compute segments (all in ms)
            load_ms  = (t_load_end   - t_load_start) * 1e3
            gpu_ms   = evt_start.elapsed_time(evt_end)
            total_ms = (t_total_end  - t_load_start) * 1e3
            idle_ms  = total_ms - load_ms - gpu_ms

            cpu_load_times.append(load_ms)
            gpu_times.append(gpu_ms)
            cpu_idle_times.append(idle_ms)

            print(
                f"Epoch {epoch:2d} | "
                f"CPU load+aug {load_ms:6.2f} ms | "
                f"GPU compute   {gpu_ms:6.2f} ms | "
                f"CPU idle      {idle_ms:6.2f} ms | "
                f"total         {total_ms:6.2f} ms"
            )
        
        print("──────────────────────────────────────────────────────────────")
        print("──────────────────────────────────────────────────────────────")
        print("AVERAGE OVER 50 BATCHES")

        # ─── PRINT STATS ───────────────────────────────────────────────────────
        print(
            f"Epoch {epoch:2d} → "
            f"Sum CPU Load times {sum(cpu_load_times)} | "
            f"Sum GPU times     {sum(gpu_times)} | "
            f"Sum CPU Idle times {sum(cpu_idle_times)} | "
            f"CPU load+aug avg {sum(cpu_load_times)/len(cpu_load_times):6.2f} ms | "
            f"GPU compute avg {sum(gpu_times)      /len(gpu_times):6.2f} ms | "
            f"CPU idle avg     {sum(cpu_idle_times)/len(cpu_idle_times):6.2f} ms"
        )

# ──────────────────────────────────────────────────────────────────────────────
# 4) LAUNCH ALL EXPERIMENTS
# ──────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    experiments = [
        {  # Food-101 @ 224×224 with heavy augmentations (inline workers)
            'dataset':    'food101',
            'data_dir':   '/n/idreos_lab/users/1/aadit_tori/',
            'image_size': 224,
            'batch_size': 32,
            'num_workers': 0,
        },
                {  # CIFAR-10 @ 32×32, light transforms
            'dataset':    'cifar10',
            'data_dir':   '/n/idreos_lab/users/1/aadit_tori/',
            'image_size': 32,
            'batch_size': 128,
            'num_workers': 4,
        },
        {  # ImageNet-1k @ 224×224, default transforms
            'dataset':    'imagenet1k',
            'data_dir':   '/n/idreos_lab/users/usirin/datasets/imagenet_subsets/imagenet_training_1000class/'
                          'train',
            'image_size': 224,
            'batch_size': 64,
            'num_workers': 4,
        },
        {  # ImageNet-1k @ 512×512, default transforms
            'dataset':    'imagenet1k',
            'data_dir':   '/n/idreos_lab/users/usirin/datasets/imagenet_subsets/imagenet_training_1000class/'
                          'train',
            'image_size': 512,
            'batch_size': 32,
            'num_workers': 4,
        },
    ]

    for exp in experiments:
        run_experiment(**exp)
