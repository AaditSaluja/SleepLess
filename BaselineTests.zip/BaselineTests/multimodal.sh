#!/bin/bash
#SBATCH -c 32                                # CPU cores
#SBATCH --gres=gpu:1                           # one GPU
#SBATCH -t 0-02:00                             # D-HH:MM
#SBATCH -p gpu_test                            # Partition to submit to
#SBATCH --mem=64000
#SBATCH -o run_multimod_%j.out
#SBATCH -e run_multimod_%j.err

module load python/3.10.9-fasrc01 cuda/12.0.1-fasrc01 cudnn
mamba activate whatover

# --- PROFILING SECTION --------------------------------

echo "==== SLURM ENVIRONMENT ===="
echo "Job ID:            $SLURM_JOB_ID"
echo "CPUs per task:     $SLURM_CPUS_PER_TASK"
echo "CPUs on node:      $SLURM_CPUS_ON_NODE"
echo "Nodes allocated:   $SLURM_JOB_NUM_NODES"
echo

echo "==== CPU TOPOLOGY (lscpu) ===="
lscpu | grep -E 'Model name|Socket|Core|Thread|^CPU'
echo

echo "==== CORE COUNT ===="
nproc --all
echo

echo "==== MEMORY ===="
free -h
echo

echo "==== NUMA (if available) ===="
if which numactl &> /dev/null; then
  numactl --hardware | head -n 5
fi
echo "--------------------------------"
# ------------------------------------------------------

# Pin threads and seeds for reproducibility
export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
export MKL_NUM_THREADS=1
export PYTHONHASHSEED=0

python Multimodal.py
